# Documents

- [Architecture Overview](./architecture.md)
- [IBFT 2.0 Light Client spec](./ibft2-light-client.md)
